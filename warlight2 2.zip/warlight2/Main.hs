import System.IO
import Control.Monad
import Control.Monad.IO.Class
import Data.List

data World = World

main :: IO ()
main = run World

run :: World -> IO ()
run world = do
    isOpen <- hIsOpen stdin
    unless isOpen main
    input <- getLine
    -- let nextWorld = step input world
    putStrLn "something"
    hPutStrLn stderr input



